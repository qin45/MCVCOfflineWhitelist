package com.mcvcofflinewhitelist.auth.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Custom payload for the {@code mcvcofflinewhitelist:auth} plugin message channel.
 *
 * <p>The payload carries a simple pipe-delimited text protocol:
 * {@code type|uuid|username|...}</p>
 */
public record AuthPayload(String text) implements class_8710 {

    public static final class_8710.class_9154<AuthPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("mcvcofflinewhitelist", "auth"));

    /** Codec using Minecraft's length-prefixed string serialisation. */
    public static final class_9139<ByteBuf, AuthPayload> CODEC =
            class_9139.method_56438(
                    (payload, buf) -> ((class_2540) buf).method_10814(payload.text()),
                    (buf) -> new AuthPayload(((class_2540) buf).method_10800(32767))
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
