package com.mcvcofflinewhitelist.auth.network;

import io.netty.buffer.ByteBuf;
import java.nio.charset.StandardCharsets;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * Custom payload for the {@code mcvcofflinewhitelist:auth} plugin message channel.
 *
 * <p>The payload carries a simple pipe-delimited text protocol:
 * {@code type|uuid|username|...}</p>
 *
 * <p>IMPORTANT: We encode as raw UTF-8 bytes (without a VarInt length prefix)
 * so that Velocity's {@code PluginMessageEvent.getData()} can read the text
 * directly without needing to strip a Minecraft-style length prefix.</p>
 */
public record AuthPayload(String text) implements class_8710 {

    public static final class_8710.class_9154<AuthPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("mcvcofflinewhitelist", "auth"));

    /** Codec using raw UTF-8 bytes (no VarInt length prefix). */
    public static final class_9139<ByteBuf, AuthPayload> CODEC =
            class_9139.method_56438(
                    (payload, buf) -> buf.writeBytes(payload.text().getBytes(StandardCharsets.UTF_8)),
                    (buf) -> {
                        byte[] bytes = new byte[buf.readableBytes()];
                        buf.readBytes(bytes);
                        return new AuthPayload(new String(bytes, StandardCharsets.UTF_8));
                    }
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
