package com.mcvcofflinewhitelist.auth.command;

import com.mcvcofflinewhitelist.auth.AuthManager;
import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * /login <password> — authenticate after registration.
 */
public class LoginCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, MCVCAuthMod mod) {
        dispatcher.register(class_2170.method_9247("login")
                .then(class_2170.method_9244("password", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            class_2168 source = ctx.getSource();
                            class_3222 player = source.method_44023();
                            if (player == null) return 0;

                            String password = StringArgumentType.getString(ctx, "password");
                            var auth = mod.getAuthManager();
                            String username = player.method_5477().getString();

                            if (!auth.needsAuth(player.method_5667())) {
                                player.method_43496(class_2561.method_43470("§a已验证，无需重复登录"));
                                return 1;
                            }

                            if (!auth.isRegistered(username)) {
                                player.method_43496(class_2561.method_43470("§c尚未注册！请使用 /register <密码> <确认密码>"));
                                return 1;
                            }

                            if (auth.verifyPassword(username, password)) {
                                auth.markAuthenticated(player.method_5667());
                                mod.getNetworkHandler().sendAuthSuccess(player);
                                player.method_43496(class_2561.method_43470("§a[MCVCAuth] §a登录成功！"));
                                MCVCAuthMod.LOGGER.info("Player '{}' logged in", username);
                            } else {
                                player.method_43496(class_2561.method_43470("§c[MCVCAuth] §c密码错误，请重试"));
                            }
                            return 1;
                        }))
                .executes(ctx -> {
                    ctx.getSource().method_9213(class_2561.method_43470("用法: /login <密码>"));
                    return 0;
                })
        );
    }
}
