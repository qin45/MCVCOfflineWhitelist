package com.mcvcofflinewhitelist.auth.command;

import com.mcvcofflinewhitelist.auth.AuthManager;
import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * /register <password> <confirm> — set a password for the first time.
 */
public class RegisterCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher, MCVCAuthMod mod) {
        dispatcher.register(class_2170.method_9247("register")
                .then(class_2170.method_9244("password", StringArgumentType.string())
                        .then(class_2170.method_9244("confirm", StringArgumentType.string())
                                .executes(ctx -> {
                                    class_2168 source = ctx.getSource();
                                    class_3222 player = source.method_44023();
                                    if (player == null) return 0;

                                    String password = StringArgumentType.getString(ctx, "password");
                                    String confirm = StringArgumentType.getString(ctx, "confirm");
                                    var auth = mod.getAuthManager();
                                    String username = player.method_5477().getString();

                                    if (!auth.needsAuth(player.method_5667())) {
                                        player.method_43496(class_2561.method_43470("§aYou are already authenticated."));
                                        return 1;
                                    }

                                    if (auth.isRegistered(username)) {
                                        player.method_43496(class_2561.method_43470("§cYou are already registered! Use /login <password>"));
                                        return 1;
                                    }

                                    if (!password.equals(confirm)) {
                                        player.method_43496(class_2561.method_43470("§cPasswords do not match!"));
                                        return 1;
                                    }

                                    if (password.length() < 4) {
                                        player.method_43496(class_2561.method_43470("§cPassword must be at least 4 characters!"));
                                        return 1;
                                    }

                                    auth.registerPassword(username, password);
                                    auth.markAuthenticated(player.method_5667());
                                    mod.getNetworkHandler().sendAuthSuccess(player);
                                    player.method_43496(class_2561.method_43470("§a[MCVCAuth] §aRegistered and authenticated!"));
                                    MCVCAuthMod.LOGGER.info("Player '{}' registered password", username);
                                    return 1;
                                })))
                .executes(ctx -> {
                    ctx.getSource().method_9213(class_2561.method_43470("Usage: /register <password> <confirm>"));
                    return 0;
                })
        );
    }
}
