package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import net.minecraft.class_2828;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels movement packets from unauthenticated players, freezing
 * them in place until they authenticate.
 */
@Mixin(class_3244.class)
public class PlayerMoveMixin {

    @Shadow
    private class_3222 player;

    @Inject(method = "onPlayerMove", at = @At("HEAD"), cancellable = true)
    public void onPlayerMove(class_2828 packet, CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            // Cancel movement — player stays in place on server side.
            // Send a position sync so the client rubber-bands back.
            player.field_13987.method_14372();
            ci.cancel();
        }
    }
}
