package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import net.minecraft.class_2828;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Prevents unauthenticated players from moving or turning.
 *
 * <p><b>Strategy (three layers):</b><br>
 * <ol>
 *   <li><b>Cancels {@code onPlayerMove}</b> — server never processes
 *       incoming position/rotation changes.</li>
 *   <li><b>Rate-limited {@code requestTeleport}</b> — periodically
 *       rubber-bands the client back to the freeze point so the local
 *       viewport snaps back. Throttled to avoid "moved too fast" kicks.</li>
 *   <li><b>{@code playerTick()} cancellation</b> (separate mixin) —
 *       prevents ALL tick processing on the player entity.</li>
 * </ol>
 * </p>
 */
@Mixin(class_3244.class)
public class PlayerMoveMixin {

    @Shadow
    private class_3222 player;

    // ── Freeze position ───────────────────────────────────────────────

    @Unique
    private double mcvcauth_freezeX;

    @Unique
    private double mcvcauth_freezeY;

    @Unique
    private double mcvcauth_freezeZ;

    @Unique
    private float mcvcauth_freezeYaw;

    @Unique
    private float mcvcauth_freezePitch;

    @Unique
    private boolean mcvcauth_freezeInitialized = false;

    /** Nano time of the last teleport — rate-limit to avoid spam kicks. */
    @Unique
    private long mcvcauth_lastTeleport = 0L;

    /** Minimum interval between teleport packets (nano = ms × 1_000_000). */
    @Unique
    private static final long TELEPORT_INTERVAL_NANO = 500_000_000L; // 500 ms

    // ── Cancel movement packets ───────────────────────────────────────

    /**
     * Discards position/rotation packets before the server processes them.
     */
    @Inject(method = "onPlayerMove", at = @At("HEAD"), cancellable = true)
    public void onPlayerMove(class_2828 packet, CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            ci.cancel();
        }
    }

    // ── Periodic teleport (client rubber-band) ────────────────────────

    /**
     * After every tick, teleport the client back to the freeze position.
     * Rate-limited so we don't trigger the anti-cheat "moved too fast" check.
     */
    @Inject(method = "tick", at = @At("TAIL"))
    public void onTickTail(CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            // Capture initial position on first tick after needsAuth
            if (!mcvcauth_freezeInitialized) {
                mcvcauth_freezeX = player.method_23317();
                mcvcauth_freezeY = player.method_23318();
                mcvcauth_freezeZ = player.method_23321();
                mcvcauth_freezeYaw = player.method_36454();
                mcvcauth_freezePitch = player.method_36455();
                mcvcauth_freezeInitialized = true;
                MCVCAuthMod.LOGGER.info("Freezing '{}' at ({}, {}, {})",
                        player.method_5477().getString(),
                        Math.round(mcvcauth_freezeX),
                        Math.round(mcvcauth_freezeY),
                        Math.round(mcvcauth_freezeZ));
            }

            // Rate-limited teleport back to freeze point
            long now = System.nanoTime();
            if (now - mcvcauth_lastTeleport >= TELEPORT_INTERVAL_NANO) {
                player.field_13987.method_14363(
                        mcvcauth_freezeX, mcvcauth_freezeY, mcvcauth_freezeZ,
                        mcvcauth_freezeYaw, mcvcauth_freezePitch);
                mcvcauth_lastTeleport = now;
            }
        } else if (mcvcauth_freezeInitialized) {
            // Player authenticated — cleanup
            mcvcauth_freezeInitialized = false;
        }
    }
}
