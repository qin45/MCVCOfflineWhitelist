package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels {@link class_3222#method_14226()} for unauthenticated
 * players, preventing ALL per-tick processing — movement, item use,
 * potion effects, health regen, etc.
 *
 * <p>Also keeps the player invisible and invulnerable during auth so
 * other players cannot see or interact with them.</p>
 */
@Mixin(class_3222.class)
public class PlayerTickMixin {

    @Unique
    private final class_3222 mcvcauth_player = (class_3222) (Object) this;

    @Inject(method = "playerTick", at = @At("HEAD"), cancellable = true)
    public void onPlayerTick(CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(mcvcauth_player.method_5667())) {
            // Hide from other players and prevent damage
            if (!mcvcauth_player.method_5767()) {
                mcvcauth_player.method_5648(true);
            }
            if (!mcvcauth_player.method_5655()) {
                mcvcauth_player.method_5684(true);
            }
            ci.cancel();
        }
    }
}
