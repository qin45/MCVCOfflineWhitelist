package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.AuthManager;
import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import com.mojang.brigadier.ParseResults;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts command execution to block unauthorized players
 * from using any commands except /login and /register.
 */
@Mixin(class_2170.class)
public class PlayerAuthMixin {

    @Inject(method = "execute", at = @At("HEAD"), cancellable = true)
    public void onExecute(ParseResults<class_2168> parseResults, String command,
                          CallbackInfo ci) {
        class_2168 source = parseResults.getContext().getSource();
        if (!(source.method_9228() instanceof class_3222 player)) {
            return;
        }

        var auth = MCVCAuthMod.getInstance().getAuthManager();
        if (!auth.needsAuth(player.method_5667())) {
            return;
        }

        // Allow /login, /l, /register, /reg
        String trimmed = command.trim().toLowerCase();
        if (trimmed.startsWith("/login") || trimmed.startsWith("/l ") || trimmed.equals("/l")
                || trimmed.startsWith("/register") || trimmed.startsWith("/reg ")
                || trimmed.equals("/reg")) {
            return;
        }

        // Block everything else
        source.method_9213(class_2561.method_43470("§cYou must authenticate first! Use /login or /register"));
        ci.cancel();
    }
}
