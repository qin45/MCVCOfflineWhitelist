package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_2653;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Prevents unauthenticated players from moving items in any inventory
 * (hotbar, main inventory, chests, crafting tables, etc.).
 *
 * <p>Works by injecting into {@link class_1735#method_7674(class_1657)}
 * and returning {@code false} for unauthenticated players, plus sending
 * a visual update packet so the client doesn't show the item as taken.</p>
 */
@Mixin(class_1735.class)
public class SlotInteractionMixin {

    @Inject(method = "canTakeItems", at = @At("HEAD"), cancellable = true)
    public void onCanTakeItems(class_1657 playerEntity, CallbackInfoReturnable<Boolean> cir) {
        if (!(playerEntity instanceof class_3222 player)) {
            return;
        }
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            // Send a visual update so the client puts the item back
            player.field_13987.method_14364(
                    new class_2653(
                            -2,
                            0,
                            player.method_31548().field_7545,
                            player.method_31548().method_5438(player.method_31548().field_7545)));
            cir.setReturnValue(false);
        }
    }
}
