package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_2703;
import net.minecraft.class_3222;

/**
 * Filters unauthenticated players from the {@link class_2703},
 * hiding them from other players' tab lists.
 *
 * <p>Once authenticated, the player appears normally in the list.</p>
 */
@Mixin(class_2703.class)
public class PlayerListS2CPacketMixin {

    @Mutable
    @Final
    @Shadow
    private List<class_2703.class_2705> entries;

    @Unique
    private static boolean isUnauthenticated(class_3222 player) {
        return MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667());
    }

    /**
     * Multi-player constructor: filter the collection of all players.
     */
    @ModifyVariable(
            method = "<init>(Ljava/util/EnumSet;Ljava/util/Collection;)V",
            at = @At("HEAD"),
            argsOnly = true)
    private static Collection<class_3222> filterPlayerList(
            Collection<class_3222> players) {
        ArrayList<class_3222> filtered = new ArrayList<>();
        for (class_3222 player : players) {
            if (!isUnauthenticated(player)) {
                filtered.add(player);
            }
        }
        return filtered;
    }

    /**
     * Single-player constructor: clear entries if the player is unauthenticated.
     */
    @Redirect(
            method = "<init>(Lnet/minecraft/network/packet/s2c/play/PlayerListS2CPacket$Action;Lnet/minecraft/server/network/ServerPlayerEntity;)V",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/network/packet/s2c/play/PlayerListS2CPacket;entries:Ljava/util/List;",
                    opcode = Opcodes.PUTFIELD
            ))
    private void clearEntryIfUnauthenticated(
            class_2703 instance, List<class_2703.class_2705> entries,
            class_2703.class_5893 action, class_3222 player) {
        if (isUnauthenticated(player)) {
            this.entries = List.of(); // empty — don't show in tab list
        } else {
            this.entries = entries;
        }
    }
}
