package com.mcvcofflinewhitelist.auth.mixin;

import com.mcvcofflinewhitelist.auth.MCVCAuthMod;
import net.minecraft.class_2561;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Blocks interactions (block breaking, entity interaction, item use, etc.)
 * for unauthenticated players.
 *
 * <p>Each injection uses {@code require = 0} so that if a Yarn method name
 * does not match, the mixin still applies — the player can still move
 * correctly and interaction blocking is a best-effort bonus.</p>
 */
@Mixin(class_3244.class)
public class PlayerInteractionMixin {

    @Shadow
    private class_3222 player;

    /** Block digging / item drop / swap actions. */
    @Inject(method = "onPlayerAction", at = @At("HEAD"), cancellable = true, require = 0)
    public void onPlayerAction(class_2846 packet, CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            player.method_43496(class_2561.method_43470("§c请先完成验证！"));
            ci.cancel();
        }
    }

    /** Right-click block (place blocks, open chests/doors, etc.). */
    @Inject(method = "onPlayerInteractBlock", at = @At("HEAD"), cancellable = true, require = 0)
    public void onPlayerInteractBlock(class_2885 packet, CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            ci.cancel();
        }
    }

    /** Right-click entity (open villager trades, attack, etc.). */
    @Inject(method = "onPlayerInteractEntity", at = @At("HEAD"), cancellable = true, require = 0)
    public void onPlayerInteractEntity(class_2824 packet, CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            ci.cancel();
        }
    }

    /** Use item (eat, throw, etc.). */
    @Inject(method = "onPlayerInteractItem", at = @At("HEAD"), cancellable = true, require = 0)
    public void onPlayerInteractItem(class_2886 packet, CallbackInfo ci) {
        if (MCVCAuthMod.getInstance().getAuthManager().needsAuth(player.method_5667())) {
            ci.cancel();
        }
    }
}
